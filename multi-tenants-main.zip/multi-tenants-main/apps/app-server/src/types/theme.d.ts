export type boxProps = {
  flexGrow?: string
  paddingLeft?: string
}

export type divProps = {
  display?: string
}

export type listProps = {
  display: string
  width: string
}
