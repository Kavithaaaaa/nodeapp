export const CONSTS = {
  ADDITIONAL_FEATURE: [
    'Life Skills',
    'Professional Devolvement',
    'Assessments',
    'Toolkit',
    'data + Reporting',
  ],
  PROGRAMS: ['Career services', 'Curriculum', 'Integrations'],
  ADMIN_USER_ROLE: '644f4c8e45f2a92340d2e121',
  USER_REG_CONFIRM: 'User registration confirmed successfully!',
  SUCCESS_OTP: 'successfully sent otp to',
  CHANGE_PASSWORD: 'password has been changed successfully',
};
