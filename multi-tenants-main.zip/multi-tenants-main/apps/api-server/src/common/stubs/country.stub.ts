export const countryStub = [
  {
    _id: '644246a1bf5fe294afca0e13',
    sortname: 'AF',
    name: 'Afghanistan',
    states: [
      {
        $oid: '644246bb5b4630710ec6e3a9',
      },
      {
        $oid: '644246bb5b4630710ec6e3aa',
      },
    ],
    isActive: true,
    __v: 0,
  },
  {
    _id: '644246a1bf5fe294afca0e19',
    sortname: 'AI',
    name: 'Anguilla',
    states: [
      {
        $oid: '644246bb5b4630710ec6e435',
      },
    ],
    isActive: true,
    __v: 0,
  },
];
