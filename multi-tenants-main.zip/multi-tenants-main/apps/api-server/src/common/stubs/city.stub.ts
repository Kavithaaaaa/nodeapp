export const cityStub = [
  {
    _id: '644246d95f0f5ede0d856974',
    name: 'Eshkashem',
    state: {
      $oid: '644246bb5b4630710ec6e3a9',
    },
    isActive: true,
    __v: 0,
  },
  {
    _id: '644246d95f0f5ede0d85697d',
    name: 'Dahaneh-ye Ghawri',
    state: {
      $oid: '644246bb5b4630710ec6e3ab',
    },
    isActive: true,
    __v: 0,
  },
];
